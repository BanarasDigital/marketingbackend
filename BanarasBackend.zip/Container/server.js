import {
  S3Client,
  GetObjectCommand,
  PutObjectCommand,
} from "@aws-sdk/client-s3";
import fs from "node:fs/promises";
import path from "node:path";
import dotenv from "dotenv";
dotenv.config();

const ffmpeg = require("fluent-ffmpeg");

const RESOLUTIONS = [
  { name: "144p", width: 256, height: 144 },
  { name: "240p", width: 426, height: 240 },
  { name: "360p", width: 640, height: 360 },
  { name: "480p", width: 854, height: 480 },
  { name: "720p", width: 1280, height: 720 },
  { name: "1080p", width: 1920, height: 1080 },
];
const s3Client = new S3Client({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  },
});

const AWS_BUCKET_NAME = process.env.AWS_BUCKET_NAME;

async function init() {
  try {
    const getCommand = new GetObjectCommand({
      Bucket: AWS_BUCKET_NAME,
      Key: "videos/original-video.mp4",
    });

    const result = await s3Client.send(getCommand);
    const originalFilePath = path.resolve("videos/original-video.mp4");
    await fs.mkdir("videos", { recursive: true });
    const chunks = [];
    for await (const chunk of result.Body) {
      chunks.push(chunk);
    }
    const buffer = Buffer.concat(chunks);
    await fs.writeFile(originalFilePath, buffer);
    await fs.mkdir("transcoded", { recursive: true });

    const promises = RESOLUTIONS.map((resolution) => {
      const outputFile = path.resolve(
        `transcoded/video-${resolution.name}.mp4`
      );

      return new Promise((resolve, reject) => {
        ffmpeg(originalFilePath)
          .output(outputFile)
          .videoCodec("libx264")
          .audioCodec("aac")
          .size(`${resolution.width}x${resolution.height}`)
          .on("end", async () => {
            try {
              const fileBuffer = await fs.readFile(outputFile);

              const putCommand = new PutObjectCommand({
                Bucket: AWS_BUCKET_NAME_PROD,
                Key: `transcoded/video-${resolution.name}.mp4`,
                Body: fileBuffer,
                ContentType: "video/mp4",
              });

              await s3Client.send(putCommand);
              console.log(`✅ Uploaded video-${resolution.name}.mp4`);
              resolve();
            } catch (err) {
              reject(err);
            }
          })
          .on("error", (err) => reject(err))
          .format("mp4")
          .run();
      });
    });

    await Promise.all(promises);
    console.log("✅ All videos transcoded and uploaded to S3");
  } catch (err) {
    console.error("❌ Error:", err);
  }
}

init().finally(() => process.exit(0));
